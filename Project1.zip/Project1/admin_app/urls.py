from .views import *
from django.urls import path

urlpatterns = [
    path('import_zip_api/',import_zip_api,name='import_zip_api'),   ### url for import data and dump into database
    path('update_data_api/',update_data_api,name='update_data_api'),  ##### update specific data url
    path('delete_data_api/',delete_data_api,name='delete_data_api'),   #### delete specific data url
    path('search_by_name_api/',search_by_name_api,name='search_by_name_api'),   ##### url for get data using serarh by name
    path('download_csv_file/',download_csv_file,name='download_csv_file') , #### url for download csv file
    path('get_record_api/',get_record_api,name="get_record_api")
    
]