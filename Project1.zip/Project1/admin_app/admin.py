from django.contrib import admin
from .models import *

@admin.register(RecordMaster)
class RecordMasterAdmin(admin.ModelAdmin):
    list_display = ['id','code','name','open','close','high','low']

