from django.shortcuts import render
from django.http import JsonResponse
import traceback,requests
from datetime import datetime 
from django.views.decorators.csrf import csrf_exempt 
import zipfile 
import pandas as pd
from io import BytesIO
from .models import *
import csv


### api for import zip and stored data in database
@csrf_exempt
def import_zip_api(request):
    try :
        date = request.POST.get('date')
        date = datetime.strptime(date, "%Y-%m-%d")
        string_date = date.strftime('%d%m%y')
        zip_url = f'https://www.bseindia.com/download/BhavCopy/Equity/EQ{string_date}_CSV.ZIP'  
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        } 
        response = requests.get(zip_url,headers=headers)  
        response.raise_for_status()    
        with zipfile.ZipFile(BytesIO(response.content)) as zip_ref: 
            zip_ref.printdir() 
            csv_files = [name for name in zip_ref.namelist() if name.endswith('.CSV') or name.endswith('.csv')] 
            if csv_files:
                csv_filename = csv_files[0]  
                with zip_ref.open(csv_filename) as file: 
                    market_df = pd.read_csv(file)  
                for key,values in market_df.iterrows() :
                    if not RecordMaster.objects.filter(code = values['SC_CODE'],name = values['SC_NAME'],open=values['OPEN'],high=values['HIGH'],low = values['LOW'],close=values['CLOSE']).exists():
                        RecordMaster.objects.create(code = values['SC_CODE'],name = values['SC_NAME'],open=values['OPEN'],high=values['HIGH'],low = values['LOW'],close=values['CLOSE'])
                return JsonResponse({'status':200,'msg': 'Data import successfully.'}) 
            else:
                return JsonResponse({'status':403,'msg': "No csv found in above zip."})  
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})


######## api for update specific data 
@csrf_exempt
def update_data_api(request): 
    try :
        r_id = request.POST.get('id') 
        search_name = request.POST.get('search_name')
        code = request.POST.get('code')
        name = request.POST.get('name')
        open = request.POST.get('open')
        high = request.POST.get('high')
        close = request.POST.get('close')
        low = request.POST.get('low')
        if RecordMaster.objects.filter(id = r_id).exists():
            obj = RecordMaster.objects.get(id=r_id)
            if code :
                obj.code = code
            if name :
                obj.name = name
            if open :
                obj.open = open
            if high :
                obj.high = high
            if low :
                obj.low = low
            if close :
                obj.close = close
            obj.save()
            data_obj = RecordMaster.objects.filter(name__icontains = search_name).values()
            return JsonResponse({"status":200,'msg':'Data updated successfully.','data_obj':list(data_obj)})
        else : return JsonResponse({"status":403,'msg':'Invalid record id.'})
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})


### api for delete specific data 
@csrf_exempt
def delete_data_api(request):
    try :
        r_id = request.POST.get('id')
        search_name = request.POST.get('search_name') 
        if RecordMaster.objects.filter(id = r_id).exists():
            RecordMaster.objects.get(id=r_id).delete() 
            data_obj = RecordMaster.objects.filter(name__icontains = search_name).values()
            return JsonResponse({"status":200,'msg':'Data deleted successfully.','data_obj':list(data_obj)})
        else : return JsonResponse({"status":403,'msg':'Invalid record id.'})
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})


### api for search record by name
@csrf_exempt
def search_by_name_api(request):
    try : 
        search_name = request.POST.get('search_name')  
        data_obj = RecordMaster.objects.filter(name__icontains = search_name).values()
        return JsonResponse({"status":200,'msg':'success.','data_obj':list(data_obj)}) 
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})


### api for show all records
@csrf_exempt
def get_record_api(request):
    try :   
        data_obj = RecordMaster.objects.all().values()
        return JsonResponse({"status":200,'msg':'success.','data_obj':list(data_obj)}) 
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})



###### api for download csv file
@csrf_exempt
def download_csv_file(request): 
    try :
        search_name = request.POST.get('search_name')   
        data_obj = RecordMaster.objects.filter(name__icontains = search_name).values('code','name','open','high','low','close')  
        file_name = f'Equity_{datetime.now().date()}.csv'
        with open(file_name, 'w', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file) 
            writer.writerow(['CODE', 'NAME', 'OPEN','HIGH', 'LOW', 'CLOSE'])    
            for row in data_obj: 
                writer.writerow([row['code'], row['name'], row['open'], row['high'], row['low'], row['close']]) 
        return JsonResponse({'status':200,'msg':'success','file_name':file_name})
    except :
        traceback.print_exc()
        return JsonResponse({'status':403,'msg': "Something went wrong."})
 